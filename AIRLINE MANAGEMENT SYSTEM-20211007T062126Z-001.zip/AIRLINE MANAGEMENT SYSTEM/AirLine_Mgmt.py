from tkinter import *
from tkinter import ttk



from tkinter import messagebox
from tkinter import scrolledtext
import sqlite3



root=Tk()
root.geometry("1400x800")
root.title("AIR INDIA")

Userair=StringVar()
Passair=StringVar()

frameair=Frame(root,bg="white")
frameair.pack(side="right",fill=BOTH,expand=True)


filename = PhotoImage(file="air.png")
background_label1 = Label(frameair, image=filename)
background_label1.place(x=0, y=0, relwidth=1, relheight=1)

labeltitle=Label(frameair,text="AIR INDIA RESERVATION",font=("times new roman",25,"bold"),bg="khaki",relief="raised")
labeltitle.pack(side=TOP,fill=X)

labelusr=Label(frameair,text="Username",font=("bold calibri",18),bg="white",relief="raised")
labelusr.place(x=780,y=180)
entryusr=Entry(frameair,width="20",bg="light blue",font=("bold calibri",12),textvariable=Userair)
entryusr.place(x=940,y=180,height=30)

labelpswd=Label(frameair,text="Password",font=("bold calibri",18),bg="white",relief="raised")
labelpswd.place(x=780,y=240)
entrypswd=Entry(frameair,width="20",bg="light blue",show="*",font=("bold calibri",12),textvariable=Passair)
entrypswd.place(x=940,y=240,height=30)



def AirLogin():
	global countera
	countera = 0
	counterb = 0
	counterc = 0
	counterd = 0
	a1=Userair.get()
	a2=Passair.get()

	if a1 == str("yash") and a2 == str("soni"):
		messagebox.showinfo("AIR INDIA:","Login Successfully Done")
		btnair.config(state = NORMAL)
		btnsch.config(state = NORMAL)
		btnflight.config(state = NORMAL)
	else:
		messagebox.showinfo("AIR INDIA:","Login Invalid")



		

btnlog=Button(frameair,text="Login",width="15",font=("calibri",12),bg="khaki",command=AirLogin)
btnlog.place(x=760,y=300)

def AirReset():
	Userair.set("")
	Passair.set("")
	btnair.config(state = DISABLED)
	btnsch.config(state = DISABLED)
	btnflight.config(state = DISABLED)


btnrst=Button(frameair,text="Reset",width="15",font=("calibri",12),bg="khaki",command=AirReset)
btnrst.place(x=900,y=300)

def AirExit():
	Exit=messagebox.askyesno("Pharmacy Management System","Confirm : if you want to exit")
	if Exit >0:
		return

btnext=Button(frameair,text="Exit",width="15",font=("calibri",12),bg="khaki",command=AirExit)
btnext.place(x=1040,y=300)

def Airlogout():
	a1=Userair.get()
	a2=Passair.get()

	if a1 == str("yash") and a2 == str("soni"):
		messagebox.showinfo("AIR INDIA:","Logout Successfully Done")
		btnair.config(state = DISABLED)
		btnsch.config(state = DISABLED)
		btnflight.config(state = DISABLED)
	else:
		messagebox.showinfo("AIR INDIA:","Logout Invalid")





btnout=Button(frameair,text="Logout",width="20",font=("calibri",12),bg="khaki",command=Airlogout)
btnout.place(x=900,y=350)



def Air_window():
	newwindow=Toplevel(root)
	b=window1(newwindow)


btnair=Button(frameair,width=10,text="Flight Info",bg="grey",font=("calibri,bold",15),state=DISABLED,command=Air_window)
btnair.place(x=50,y=50)
		

def Flight_window():
	newwindow=Toplevel(root)
	b=window2(newwindow)

btnflight=Button(frameair,width=10,text="Book Flight",bg="grey",font=("calibri,bold",15),state=DISABLED,command=Flight_window)
btnflight.place(x=380,y=50)



def Schedule_window():
	newwindow=Toplevel(root)
	b=window4(newwindow)

btnsch=Button(frameair,width=12,text="Flight Schedule",bg="grey",font=("calibri,bold",14),state=DISABLED,command=Schedule_window)
btnsch.place(x=190,y=50)

def Payment_window():
	newwindow=Toplevel(root)
	b=window3(newwindow)





class window1:
	def __init__(self,root1):
		self.root1 = root1
		self.root1.title("Flight Information")
		self.root1.geometry("1400x700")
		self.framef=Frame(self.root1)
		self.framef.pack()

		self.Flight=StringVar()
		self.FlightName=StringVar()
		self.Source=StringVar()
		self.Destination=StringVar()
		self.Departure=StringVar()
		self.Arrival=StringVar()
		self.Charges=StringVar()
		self.Date=StringVar()

		self.FgtNme=StringVar()
		self.Flgt=StringVar()



		label_title=Label(self.root1,text="Flight Info System",font=("times new roman",20,"bold"),bg="khaki",relief="raised")
		label_title.pack(side=TOP,fill=X)

		Manage_frame1=Frame(self.root1,width=1400,height=800,relief=RIDGE,bd=4,bg="light grey")
		Manage_frame1.pack(fill=BOTH)

		self.label3=Label(Manage_frame1,text="Flight ID:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.label3.place(x=0,y=70,width=150,height=30)
		self.entry1=Entry(Manage_frame1,width="20",font="5",textvariable=self.Flight)
		self.entry1.place(x=190,y=70,height=25)

		self.label4=Label(Manage_frame1,text="Flight Name:",font=("bold 		arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.label4.place(x=400,y=70,width=150,height=30)
		self.entry2=Entry(Manage_frame1,width="20",font="5",textvariable=self.FlightName)
		self.entry2.place(x=590,y=70,height=25)

		self.label5=Label(Manage_frame1,text="Source:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.label5.place(x=0,y=110,width=150,height=30)
		self.entry3=Entry(Manage_frame1,width="20",font="5",textvariable=self.Source)
		self.entry3.place(x=190,y=110,height=25)

		self.label6=Label(Manage_frame1,text="Destination:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.label6.place(x=400,y=110,width=150,height=30)
		self.entry4=Entry(Manage_frame1,width="20",font="5",textvariable=self.Destination)
		self.entry4.place(x=590,y=110,height=25)

		self.label7=Label(Manage_frame1,text="Departure:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.label7.place(x=0,y=150,width=150,height=30)
		self.entry5=Entry(Manage_frame1,width="20",font="5",textvariable=self.Departure)
		self.entry5.place(x=190,y=150,height=25)

		self.label8=Label(Manage_frame1,text="Arrive Time:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.label8.place(x=400,y=150,width=150,height=30)
		self.entry6=Entry(Manage_frame1,width="20",font="5",textvariable=self.Arrival)
		self.entry6.place(x=590,y=150,height=25)

		self.label9=Label(Manage_frame1,text="Flight Charges:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.label9.place(x=0,y=190,width=150,height=30)
		self.entry7=Entry(Manage_frame1,width="20",font="5",textvariable=self.Charges)
		self.entry7.place(x=190,y=190,height=25)

		self.label10=Label(Manage_frame1,text="Date of Departure:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.label10.place(x=400,y=190,width=150,height=30)
		self.entry8=Entry(Manage_frame1,width="20",font="5",textvariable=self.Date)
		self.entry8.place(x=590,y=190,height=25)


		self.buttona=Button(Manage_frame1,text="Add",bg="khaki",font=("bold arial",14),width="15",height="1",command=self.add_flight)
		self.buttona.place(x=850,y=80)

		self.buttonb=Button(Manage_frame1,text="Reset",bg="khaki",font=("bold arial",14),width="15",height="1",command=self.IReset_flight)
		self.buttonb.place(x=850,y=130)

		self.buttonc=Button(Manage_frame1,text="Update",bg="khaki",font=("bold arial",14),width="15",height="1",command=self.Update_flight)
		self.buttonc.place(x=850,y=180)

		self.buttond=Button(Manage_frame1,text="Delete",bg="khaki",font=("bold arial",14),width="15",height="1",command=self.delete_flight)
		self.buttond.place(x=850,y=230)

		self.label1a=Label(Manage_frame1,text="Search By:",font=("bold arial",14),fg="black",bg="light grey",relief="ridge",borderwidth="2")
		self.label1a.place(x=1100,y=40,width=150,height=30)


		searchbtna=Button(Manage_frame1,text="FlightName",width=15,font=("times new roman",13,"bold"),command=self.search_flight)
		searchbtna.place(x=1200,y=85,width=140,height=30)
		entry_searcha=Entry(Manage_frame1,textvariable=self.FgtNme,font=("calibri",12),bd=4,relief=GROOVE)
		entry_searcha.place(x=1050,y=85,width=130,height=30)

		showbtna=Button(Manage_frame1,text="Showall",width=15,font=("times new roman",13,"bold"),command=self.fetch_data)
		showbtna.place(x=1150,y=185,width=100,height=30)

		searchbtnb=Button(Manage_frame1,text="FlightID",width=15,font=("times new roman",15,"bold"),command=self.Search_Flight)
		searchbtnb.place(x=1200,y=135,width=140,height=30)
		entry_searchb=Entry(Manage_frame1,textvariable=self.Flgt,font=("calibri",12),bd=4,relief=GROOVE)
		entry_searchb.place(x=1050,y=135,width=130,height=30)





		info_framea=Frame(Manage_frame1,relief=RIDGE,bd="2",bg="light blue")
		info_framea.place(x=30,y=280,width=1300,height=400)


		scroll1=Scrollbar(info_framea,orient=HORIZONTAL)
		scroll1.pack(side=BOTTOM,fill=X)
		scroll2=Scrollbar(info_framea,orient=VERTICAL)
		scroll2.pack(side=RIGHT,fill=Y)
		self.Flight_table=ttk.Treeview(info_framea,columns=("Flight","FlightName","Source","Destination","Departure","Arrival","Charges","DeptTime"),xscrollcommand=scroll1.set,yscrollcommand=scroll2.set)
		scroll1.config(command=self.Flight_table.xview)
		scroll2.config(command=self.Flight_table.yview)

		scroll1.config(command=self.Flight_table.xview)
		scroll2.config(command=self.Flight_table.yview)

		self.Flight_table.heading("Flight",text="Flight ID")
		self.Flight_table.heading("FlightName",text="FlightName")
		self.Flight_table.heading("Source",text="Source")
		self.Flight_table.heading("Destination",text="Destination")
		self.Flight_table.heading("Departure",text="Departure")
		self.Flight_table.heading("Arrival",text="ArriveTime")
		self.Flight_table.heading("Charges",text="Flight Charge")
		self.Flight_table.heading("DeptTime",text="DeptTime")

		self.Flight_table['show']='headings'
		self.Flight_table.column("Flight",width=100)
		self.Flight_table.column("FlightName",width=100)
		self.Flight_table.column("Source",width=100)
		self.Flight_table.column("Destination",width=100)
		self.Flight_table.column("Departure",width=100)
		self.Flight_table.column("Arrival",width=100)
		self.Flight_table.column("Charges",width=100)
		self.Flight_table.column("DeptTime",width=100)

		self.Flight_table.pack(fill=BOTH,expand=True)
		self.fetch_data()

		self.Flight_table.bind("<ButtonRelease-1>",self.get_cursor)


	def add_flight(self):
		connection=sqlite3.connect("Airline.db")
		cursor=connection.cursor()

		line="insert into ft values('{}','{}','{}','{}','{}','{}','{}','{}')".format(self.Flight.get(),self.FlightName.get(),self.Source.get(),self.Destination.get(),self.Departure.get(),self.Arrival.get(),self.Charges.get(),self.Date.get())
		cursor.execute(line)
		connection.commit()
		self.fetch_data()
		


		connection = sqlite3.connect("Airline.db")
		cursor=connection.cursor()
		
		line="select * from ft"
		cursor.execute(line)
		for row in cursor:
			print(row)

	def fetch_data(self):
		connection=sqlite3.connect("Airline.db")
		cursor=connection.cursor()

		line="select * from ft"
		cursor.execute(line)

		rows=cursor.fetchall()
		if len(rows)!=0:
			self.Flight_table.delete(*self.Flight_table.get_children())
			for row in rows:
				self.Flight_table.insert('',END,values=row)

			connection.commit()
		connection.close()

	def get_cursor(self,ry):
		cursor_row=self.Flight_table.focus()
		contents=self.Flight_table.item(cursor_row)
		row=contents['values']
		self.Flight.set(row[0])
		self.FlightName.set(row[1])
		self.Source.set(row[2])
		self.Destination.set(row[3])
		self.Departure.set(row[4])
		self.Arrival.set(row[5])
		self.Charges.set(row[6])
		self.Date.set(row[7])

	def IReset_flight(self):
		self.Flight.set("")
		self.FlightName.set("")
		self.Source.set("")
		self.Destination.set("")
		self.Departure.set("")
		self.Arrival.set("")
		self.Charges.set("")
		self.Date.set("")
		self.Flgt.set("")
		self.FgtNme.set("")

	def delete_flight(self):
		connection=sqlite3.connect("Airline.db")
		cursor=connection.cursor()

		line="delete from ft where Flight='{}'".format(self.Flight.get())
		cursor.execute(line)
		connection.commit()

			
		self.fetch_data()

	def Update_flight(self):
		connection=sqlite3.connect("Airline.db")
		cursor=connection.cursor()
		line="update ft set FlightName='{}',Source='{}',Destination='{}',Departure='{}',Arrival='{}',Charges='{}',DeptTime='{}' where Flight='{}'".format(self.FlightName.get(),self.Source.get(),self.Destination.get(),self.Departure.get(),self.Arrival.get(),self.Charges.get(),self.Date.get(),self.Flight.get())

		cursor.execute(line)
		connection.commit()  
		self.fetch_data()

	def search_flight(self):
		connection=sqlite3.connect("Airline.db")
		cursor=connection.cursor()

		line="select * from ft where FlightName='{}'".format(self.FgtNme.get())
		cursor.execute(line)
		rows=cursor.fetchall()
		if len(rows)!=0:
			self.Flight_table.delete(*self.Flight_table.get_children())
			for row in rows:
				self.Flight_table.insert('',END,values=row)

			connection.commit()
		connection.close()


	def Search_Flight(self):
		connection=sqlite3.connect("Airline.db")
		cursor=connection.cursor()

		line="select * from ft where Flight='{}'".format(self.Flgt.get())
		cursor.execute(line)
		rows=cursor.fetchall()
		if len(rows)!=0:
			self.Flight_table.delete(*self.Flight_table.get_children())
			for row in rows:
				self.Flight_table.insert('',END,values=row)

			connection.commit()
		connection.close()


	


	try:
		connection=sqlite3.connect("Airline.db")
		cursor=connection.cursor()

		line="create table ft (Flight int Primary Key,FlightName text,Source text,Destination text,Departure text,Arrival text,Charges text,DeptTime text)"
		cursor.execute(line)
		connection.commit()
	except:
		pass


class window2:
	def __init__(self,root2):
		self.root2 = root2
		self.root2.title("Book Flight Information")
		self.root2.geometry("1400x700")
		self.frameb=Frame(self.root2)
		self.frameb.pack()

		self.ticket=StringVar()
		self.customer=StringVar()
		self.customname=StringVar()
		self.father=StringVar()
		self.birth=StringVar()
		self.chrgs=StringVar()
		self.id=StringVar()
		self.name=StringVar()
		self.chld=StringVar()
		self.dept=StringVar()
		self.journey=StringVar()
		self.address=StringVar()
		self.cont=StringVar()
		self.email=StringVar()

		self.bookname=StringVar()
		self.bookid=StringVar()
		

		label_titleb=Label(self.root2,text="Book Flight",font=("times new roman",20,"bold"),bg="khaki",relief="raised")
		label_titleb.pack(side=TOP,fill=X)

		Manage_frame2=Frame(self.root2,width=1400,height=800,relief=RIDGE,bd=4,bg="light grey")
		Manage_frame2.pack(fill=BOTH)

		self.labelfb=Label(Manage_frame2,text="FlightID:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.labelfb.place(x=0,y=40,width=150,height=30)
		self.entry1b=Entry(Manage_frame2,width="20",font="5",textvariable=self.ticket)
		self.entry1b.place(x=190,y=40,height=25)

		self.labelfb1=Label(Manage_frame2,text="Flight Name:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.labelfb1.place(x=0,y=80,width=150,height=30)
		self.entry1c=Entry(Manage_frame2,width="20",font="5",textvariable=self.customer)
		self.entry1c.place(x=190,y=80,height=25)

		self.labelfb=Label(Manage_frame2,text="ID Proof :",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.labelfb.place(x=0,y=160,width=150,height=30)
		self.entry1b=Entry(Manage_frame2,width="20",font="5",textvariable=self.customname)
		self.entry1b.place(x=190,y=160,height=25)

		self.labelfb=Label(Manage_frame2,text="Passenger Name:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.labelfb.place(x=0,y=120,width=150,height=30)
		self.entry1b=Entry(Manage_frame2,width="20",font="5",textvariable=self.father)
		self.entry1b.place(x=190,y=120,height=25)

		self.labelfb=Label(Manage_frame2,text="Gender:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.labelfb.place(x=0,y=200,width=150,height=30)

		data=["Male","Female"]
		self.gender=StringVar(Manage_frame2)
		self.gender.set("Male")
		dropdownlist=OptionMenu(Manage_frame2,self.gender,*data)
		dropdownlist.place(x=190,y=200,width=160,height=30)

		self.labelfb=Label(Manage_frame2,text="DOB:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.labelfb.place(x=0,y=240,width=150,height=30)
		self.entry1b=Entry(Manage_frame2,width="20",font="5",textvariable=self.birth)
		self.entry1b.place(x=190,y=240,height=25)

		
		self.labelfb=Label(Manage_frame2,text="Flight Charges:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.labelfb.place(x=0,y=280,width=150,height=30)
		self.entry1b=Entry(Manage_frame2,width="20",font="5",textvariable=self.chrgs)
		self.entry1b.place(x=190,y=280,height=25)

		self.labelfb=Label(Manage_frame2,text="Flight Class:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.labelfb.place(x=0,y=320,width=150,height=30)

		data=["Bussiness","Economy"]
		self.clss=StringVar(Manage_frame2)
		self.clss.set("Choose Class")
		dropdownlist=OptionMenu(Manage_frame2,self.clss,*data)
		dropdownlist.place(x=190,y=320,width=160,height=30)


		self.labelfb=Label(Manage_frame2,text="Seats:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.labelfb.place(x=420,y=40,width=150,height=30)
		self.entry1b=Entry(Manage_frame2,width="20",font="5",textvariable=self.id)
		self.entry1b.place(x=610,y=40,height=25)

		self.labelfb=Label(Manage_frame2,text="Adult:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.labelfb.place(x=420,y=80,width=150,height=30)
		self.entry1b=Entry(Manage_frame2,width="20",font="5",textvariable=self.name)
		self.entry1b.place(x=610,y=80,height=25)

		self.labelfb=Label(Manage_frame2,text="Child:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.labelfb.place(x=420,y=120,width=150,height=30)
		self.entry1b=Entry(Manage_frame2,width="20",font="5",textvariable=self.chld)
		self.entry1b.place(x=610,y=120,height=25)


		self.labelfb=Label(Manage_frame2,text="Departure Time:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.labelfb.place(x=420,y=160,width=150,height=30)
		self.entry1b=Entry(Manage_frame2,width="20",font="5",textvariable=self.dept)
		self.entry1b.place(x=610,y=160,height=25)

		self.labelfb=Label(Manage_frame2,text="Date of Journey:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.labelfb.place(x=420,y=200,width=150,height=30)
		self.entry1b=Entry(Manage_frame2,width="20",font="5",textvariable=self.journey)
		self.entry1b.place(x=610,y=200,height=25)

		self.labelfb=Label(Manage_frame2,text="Address:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.labelfb.place(x=420,y=240,width=150,height=30)
		self.entry1b=Entry(Manage_frame2,width="20",font="5",textvariable=self.address)
		self.entry1b.place(x=610,y=240,height=25)


		self.labelfb=Label(Manage_frame2,text="Contact No:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.labelfb.place(x=420,y=280,width=150,height=30)
		self.entry1b=Entry(Manage_frame2,width="20",font="5",textvariable=self.cont)
		self.entry1b.place(x=610,y=280,height=25)

		self.labelfb=Label(Manage_frame2,text="Email:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.labelfb.place(x=420,y=320,width=150,height=30)
		self.entry1b=Entry(Manage_frame2,width="20",font="5",textvariable=self.email)
		self.entry1b.place(x=610,y=320,height=25)




		
		self.buttona=Button(Manage_frame2,text="Payment",bg="khaki",font=("bold arial",14),width="15",height="1",command=Payment_window)
		self.buttona.place(x=870,y=260)

		self.buttona=Button(Manage_frame2,text="Add",bg="khaki",font=("bold arial",14),width="15",height="1",command=self.Book_flight)
		self.buttona.place(x=870,y=60)


		self.buttonb=Button(Manage_frame2,text="Reset",bg="khaki",font=("bold arial",14),width="15",height="1",command=self.IReset_book)
		self.buttonb.place(x=870,y=110)

		self.buttonc=Button(Manage_frame2,text="Update",bg="khaki",font=("bold arial",14),width="15",height="1",command=self.Update_book)
		self.buttonc.place(x=870,y=160)

		self.buttond=Button(Manage_frame2,text="Delete",bg="khaki",font=("bold arial",14),width="15",height="1",command=self.delete_book)
		self.buttond.place(x=870,y=210)

		self.label1b=Label(Manage_frame2,text="Search By:",font=("bold arial",14),fg="black",bg="light grey",relief="ridge",borderwidth="2")
		self.label1b.place(x=1150,y=40,width=150,height=30)


		searchbtna=Button(Manage_frame2,text="Flightname",width=15,font=("times new roman",13,"bold"),command=self.search_book)
		searchbtna.place(x=1250,y=85,width=140,height=30)
		entry_searcha=Entry(Manage_frame2,textvariable=self.bookname,font=("calibri",12),bd=4,relief=GROOVE)
		entry_searcha.place(x=1100,y=85,width=130,height=30)

		showbtna=Button(Manage_frame2,text="Showall",width=15,font=("times new roman",13,"bold"),command=self.Fetch_book)
		showbtna.place(x=1200,y=195,width=120,height=30)
		
		searchbtnb=Button(Manage_frame2,text="PassengerName",width=15,font=("times new roman",15,"bold"),command=self.Search_Book)
		searchbtnb.place(x=1250,y=135,width=140,height=30)
		entry_searchb=Entry(Manage_frame2,textvariable=self.bookid,font=("calibri",12),bd=4,relief=GROOVE)
		entry_searchb.place(x=1100,y=135,width=130,height=30)



		info_frameb=Frame(Manage_frame2,relief=RIDGE,bd="2",bg="light blue")
		info_frameb.place(x=30,y=390,width=1500,height=330)


		scroll1=Scrollbar(info_frameb,orient=HORIZONTAL)
		scroll1.pack(side=BOTTOM,fill=X)
		scroll2=Scrollbar(info_frameb,orient=VERTICAL)
		scroll2.pack(side=RIGHT,fill=Y)
		self.Book_table=ttk.Treeview(info_frameb,columns=("Ticket","Customer","Name","Father","Gender","DOB","Charges","Flight","Flightname","Departure","Journey","Dept","Class","Address","Contact","Email"),xscrollcommand=scroll1.set,yscrollcommand=scroll2.set)
		scroll1.config(command=self.Book_table.xview)
		scroll2.config(command=self.Book_table.yview)

		scroll1.config(command=self.Book_table.xview)
		scroll2.config(command=self.Book_table.yview)

		self.Book_table.heading("Ticket",text="FlightID")
		self.Book_table.heading("Customer",text="FlightName")
		self.Book_table.heading("Name",text="Passenger ID")
		self.Book_table.heading("Father",text="PassengerName")
		self.Book_table.heading("Gender",text="Gender")
		self.Book_table.heading("DOB",text="DOB")
		self.Book_table.heading("Charges",text="FlightCharges")
		self.Book_table.heading("Flight",text="FlightClass")
		self.Book_table.heading("Flightname",text="Seats")
		self.Book_table.heading("Departure",text="Adult")
		self.Book_table.heading("Journey",text="Child")
		self.Book_table.heading("Dept",text="Dept Time")
		self.Book_table.heading("Class",text="Date")
		self.Book_table.heading("Address",text="Address")
		self.Book_table.heading("Contact",text="ContactNo")
		self.Book_table.heading("Email",text="Email")


		self.Book_table['show']='headings'
		self.Book_table.column("Ticket",width=100)
		self.Book_table.column("Customer",width=100)
		self.Book_table.column("Name",width=100)
		self.Book_table.column("Father",width=100)
		self.Book_table.column("Gender",width=100)
		self.Book_table.column("DOB",width=100)
		self.Book_table.column("Charges",width=100)
		self.Book_table.column("Flight",width=100)
		self.Book_table.column("Flightname",width=100)
		self.Book_table.column("Departure",width=100)
		self.Book_table.column("Journey",width=100)
		self.Book_table.column("Dept",width=100)
		self.Book_table.column("Class",width=100)
		self.Book_table.column("Address",width=100)
		self.Book_table.column("Contact",width=100)
		self.Book_table.column("Email",width=100)


		self.Book_table.pack(fill=BOTH,expand=True)
		self.Fetch_book()

		self.Book_table.bind("<ButtonRelease-1>",self.get_book)


	def Book_flight(self):
		connection=sqlite3.connect("Book.db")
		cursor=connection.cursor()

		num="insert into bk values('{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}')".format(self.ticket.get(),self.customer.get(),self.customname.get(),self.father.get(),self.gender.get(),self.birth.get(),self.chrgs.get(),self.clss.get(),self.id.get(),self.name.get(),self.chld.get(),self.dept.get(),self.journey.get(),self.address.get(),self.cont.get(),self.email.get())
		cursor.execute(num)
		connection.commit()
		self.Fetch_book()

		connection = sqlite3.connect("Book.db")
		cursor=connection.cursor()
		
		num="select * from bk"
		cursor.execute(num)
		for row in cursor:
			print(row)



	def Fetch_book(self):
		connection=sqlite3.connect("Book.db")
		cursor=connection.cursor()

		num="select * from bk"
		cursor.execute(num)

		rows=cursor.fetchall()
		if len(rows)!=0:
			self.Book_table.delete(*self.Book_table.get_children())
			for row in rows:
				self.Book_table.insert('',END,values=row)

			connection.commit()
		connection.close()

	
		

	def get_book(self,ry):
		cursor_row=self.Book_table.focus()
		contents=self.Book_table.item(cursor_row)
		row=contents['values']
		self.ticket.set(row[0])
		self.customer.set(row[1])
		self.customname.set(row[2])
		self.father.set(row[3])
		self.gender.set(row[4])
		self.birth.set(row[5])
		self.chrgs.set(row[6])
		self.clss.set(row[7])
		self.id.set(row[8])
		self.name.set(row[9])
		self.chld.set(row[10])
		self.dept.set(row[11])
		self.journey.set(row[12])
		self.address.set(row[13])
		self.cont.set(row[14])
		self.email.set(row[15])


	def IReset_book(self):
		self.ticket.set("")
		self.customer.set("")
		self.customname.set("")
		self.father.set("")
		self.gender.set("Male")
		self.birth.set("")
		self.chrgs.set("")
		self.clss.set("Choose Class")
		self.id.set("")
		self.name.set("")
		self.chld.set("")
		self.dept.set("")
		self.journey.set("")
		self.address.set("")
		self.cont.set("")
		self.email.set("")
		self.bookname.set("")
		self.bookid.set("")

	def delete_book(self):
		connection=sqlite3.connect("Book.db")
		cursor=connection.cursor()

		num="delete from bk where Ticket='{}'".format(self.ticket.get())
		cursor.execute(num)
		connection.commit()

		
		self.Fetch_book()

	def Update_book(self):
		connection=sqlite3.connect("Book.db")
		cursor=connection.cursor()
		num="update bk set Customer='{}',Name='{}',Father='{}',Gender='{}',DOB='{}',Charges='{}',Flight='{}',Flightname='{}',Departure='{}',Journey='{}',Dept='{}',Class='{}',Address='{}',Contact='{}',Email='{}' where Ticket='{}'".format(self.customer.get(),self.customname.get(),self.father.get(),self.gender.get(),self.birth.get(),self.chrgs.get(),self.clss.get(),self.id.get(),self.name.get(),self.chld.get(),self.dept.get(),self.journey.get(),self.address.get(),self.cont.get(),self.email.get(),self.ticket.get())

		cursor.execute(num)
		connection.commit()
		self.Fetch_book()

	def search_book(self):
		connection=sqlite3.connect("Book.db")
		cursor=connection.cursor()

		num="select * from bk where Customer='{}'".format(self.bookname.get())
		cursor.execute(num)
		rows=cursor.fetchall()
		if len(rows)!=0:
			self.Book_table.delete(*self.Book_table.get_children())
			for row in rows:
				self.Book_table.insert('',END,values=row)

			connection.commit()
		connection.close()


	def Search_Book(self):
		connection=sqlite3.connect("Book.db")
		cursor=connection.cursor()

		num="select * from bk where Father='{}'".format(self.bookid.get())
		cursor.execute(num)
		rows=cursor.fetchall()
		if len(rows)!=0:
			self.Book_table.delete(*self.Book_table.get_children())
			for row in rows:
				self.Book_table.insert('',END,values=row)

			connection.commit()
		connection.close()


		


	try:
		connection=sqlite3.connect("Book.db")
		cursor=connection.cursor()

		num="create table bk (Ticket int Primary Key,Customer text,Name text,Father text,Gender text,DOB text,Charges text,Flight text,Flightname text,Departure text,Journey text,Dept text,Class text,Address text,Contact text,Email text)"
		cursor.execute(num)
		connection.commit()
	except:
		pass

class window3:
	def __init__(self,root3):
		self.root3 = root3
		self.root3.title("Payment System")
		self.root3.geometry("1400x700")
		self.framec=Frame(self.root3)
		self.framec.pack()



		self.fir=StringVar()
		self.amount=StringVar()
		self.childfare=StringVar()
		self.pcls=StringVar()
		self.pid=StringVar()



		label_titleb=Label(self.root3,text="Payment Details",font=("times new roman",20,"bold"),bg="khaki",relief="raised")
		label_titleb.pack(side=TOP,fill=X)

		Manage_frame3=Frame(self.root3,width=1400,height=800,relief=RIDGE,bd=4,bg="light grey")
		Manage_frame3.pack(fill=BOTH)

		self.labelfb=Label(Manage_frame3,text="FlightID:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.labelfb.place(x=0,y=60,width=150,height=30)
		self.entry1b=Entry(Manage_frame3,width="20",font="5",textvariable=self.fir)
		self.entry1b.place(x=190,y=60,height=25)


		
		self.labelfb=Label(Manage_frame3,text="Total Seat:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.labelfb.place(x=0,y=100,width=150,height=30)
		self.entry1b=Entry(Manage_frame3,width="20",font="5",textvariable=self.amount)
		self.entry1b.place(x=190,y=100,height=25)

		self.labelfb=Label(Manage_frame3,text="Total Fare:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.labelfb.place(x=0,y=140,width=150,height=30)
		self.entry1b=Entry(Manage_frame3,width="20",font="5",textvariable=self.childfare)
		self.entry1b.place(x=190,y=140,height=25)

		self.labelfb=Label(Manage_frame3,text="Payment Method:",font=("bold arial",13),fg="black",bg="light grey",relief="raised",borderwidth="2")
		self.labelfb.place(x=0,y=180,width=150,height=30)

		data=["Paytm","Visa Card","Master Card","Cash"]
		self.paymode=StringVar(Manage_frame3)
		self.paymode.set("Choose Method")
		dropdownlist=OptionMenu(Manage_frame3,self.paymode,*data)
		dropdownlist.place(x=190,y=180,width=160,height=30)

		

		



		
		self.buttona=Button(Manage_frame3,text="Book",bg="khaki",font=("bold arial",14),width="15",height="1",command=self.Payment_flight)
		self.buttona.place(x=20,y=340)

		self.buttonb=Button(Manage_frame3,text="Reset",bg="khaki",font=("bold arial",14),width="15",height="1",command=self.IReset_payment)
		self.buttonb.place(x=20,y=390)

		self.buttonc=Button(Manage_frame3,text="Update",bg="khaki",font=("bold arial",14),width="15",height="1",command=self.Update_payment)
		self.buttonc.place(x=20,y=440)

		self.buttond=Button(Manage_frame3,text="Delete",bg="khaki",font=("bold arial",14),width="15",height="1",command=self.delete_payment)
		self.buttond.place(x=20,y=490)

		self.buttond=Button(Manage_frame3,text="Print",bg="khaki",font=("bold arial",14),width="15",height="1")
		self.buttond.place(x=20,y=540)


		self.label1b=Label(Manage_frame3,text="Search By:",font=("bold arial",14),fg="black",bg="light grey",relief="ridge",borderwidth="2")
		self.label1b.place(x=550,y=40,width=150,height=30)


		
		showbtna=Button(Manage_frame3,text="Showall",width=15,font=("times new roman",13,"bold"),command=self.Fetch_payment)
		showbtna.place(x=750,y=135,width=120,height=30)
		
		searchbtnb=Button(Manage_frame3,text="FlightID",width=15,font=("times new roman",15,"bold"),command=self.search_payment)
		searchbtnb.place(x=800,y=85,width=140,height=30)
		entry_searchb=Entry(Manage_frame3,font=("calibri",12),textvariable=self.pid,bd=4,relief=GROOVE)
		entry_searchb.place(x=650,y=85,width=130,height=30)




		info_framec=Frame(Manage_frame3,relief=RIDGE,bd="2",bg="light blue")
		info_framec.place(x=300,y=240,width=1200,height=470)


		scroll1=Scrollbar(info_framec,orient=HORIZONTAL)
		scroll1.pack(side=BOTTOM,fill=X)
		scroll2=Scrollbar(info_framec,orient=VERTICAL)
		scroll2.pack(side=RIGHT,fill=Y)

		self.Payment_table=ttk.Treeview(info_framec,columns=("Flight","Seat","Amount","Payment"),xscrollcommand=scroll1.set,yscrollcommand=scroll2.set)
		scroll1.config(command=self.Payment_table.xview)
		scroll2.config(command=self.Payment_table.yview)

		scroll1.config(command=self.Payment_table.xview)
		scroll2.config(command=self.Payment_table.yview)

		self.Payment_table.heading("Flight",text="FlightID")
		self.Payment_table.heading("Seat",text="Total Seat")
		self.Payment_table.heading("Amount",text="TotalFare")
		self.Payment_table.heading("Payment",text="PaymentMethod")
		
		self.Payment_table['show']='headings'

		self.Payment_table.column("Flight",width=100)
		self.Payment_table.column("Seat",width=100)
		self.Payment_table.column("Amount",width=100)
		self.Payment_table.column("Payment",width=100)
		
		
		self.Payment_table.pack(fill=BOTH,expand=True)
		self.Fetch_payment()

		self.Payment_table.bind("<ButtonRelease-1>",self.get_payment)



	def Payment_flight(self):
		connection=sqlite3.connect("Pay.db")
		cursor=connection.cursor()

		nump="insert into py values('{}','{}','{}','{}')".format(self.fir.get(),self.amount.get(),self.childfare.get(),self.paymode.get())
		cursor.execute(nump)
		connection.commit()
		self.Fetch_payment()

		connection = sqlite3.connect("Pay.db")
		cursor=connection.cursor()
		
		nump="select * from py"
		cursor.execute(nump)
		for row in cursor:
			print(row)

	def Fetch_payment(self):
		connection=sqlite3.connect("Pay.db")
		cursor=connection.cursor()

		nump="select * from py"
		cursor.execute(nump)

		rows=cursor.fetchall()
		if len(rows)!=0:
			self.Payment_table.delete(*self.Payment_table.get_children())
			for row in rows:
				self.Payment_table.insert('',END,values=row)

			connection.commit()
		connection.close()

	def get_payment(self,ry):
		cursor_row=self.Payment_table.focus()
		contents=self.Payment_table.item(cursor_row)
		row=contents['values']

		self.fir.set(row[0])
		self.amount.set(row[1])
		self.childfare.set(row[2])
		self.paymode.set(row[3])

	def IReset_payment(self):

		self.fir.set("")
		self.amount.set("")
		self.childfare.set("")
		self.paymode.set("Choose Method")

	def delete_payment(self):
		connection=sqlite3.connect("Pay.db")
		cursor=connection.cursor()

		nump="delete from py where Flight='{}'".format(self.fir.get())
		cursor.execute(nump)
		connection.commit()

		
		self.Fetch_payment()

	def Update_payment(self):
		connection=sqlite3.connect("Pay.db")
		cursor=connection.cursor()
		nump="update py set Seat='{}',Amount='{}',Payment='{}' where Flight='{}'".format(self.amount.get(),self.childfare.get(),self.paymode.get(),self.fir.get())

		cursor.execute(nump)
		connection.commit()
		self.Fetch_payment()


	def search_payment(self):
		connection=sqlite3.connect("Pay.db")
		cursor=connection.cursor()

		nump="select * from py where Flight='{}'".format(self.pid.get())
		cursor.execute(nump)
		rows=cursor.fetchall()
		if len(rows)!=0:
			self.Payment_table.delete(*self.Payment_table.get_children())
			for row in rows:
				self.Payment_table.insert('',END,values=row)

			connection.commit()
		connection.close()

	def search_passenger(self):
		connection=sqlite3.connect("Pay.db")
		cursor=connection.cursor()

		nump="select * from py where Passenger='{}'".format(self.pcls.get())
		cursor.execute(nump)
		rows=cursor.fetchall()
		if len(rows)!=0:
			self.Payment_table.delete(*self.Payment_table.get_children())
			for row in rows:
				self.Payment_table.insert('',END,values=row)

			connection.commit()
		connection.close()




	


		
		



	try:
		connection=sqlite3.connect("Pay.db")
		cursor=connection.cursor()

		nump="create table py (Flight int Primary key,Seat text,Amount text,Payment text)"
		cursor.execute(nump)
		connection.commit()
	except:
		pass




class window4:
	def __init__(self,root4):
		self.root4 = root4
		self.root4.title("Flight Schedule")
		self.root4.geometry("1400x700")
		self.framec=Frame(self.root4)
		self.framec.pack()

		self.Flgt=StringVar()
		self.FgtNme=StringVar()
		self.dpt=StringVar()

		label_titler=Label(self.root4,text="Flight Schedule",font=("times new roman",20,"bold"),bg="khaki",relief="raised")
		label_titler.pack(side=TOP,fill=X)

		Manage_frame4=Frame(self.root4,width=1400,height=800,relief=RIDGE,bd=4,bg="light grey")
		Manage_frame4.pack(fill=BOTH)

		self.label1b=Label(Manage_frame4,text="Search By:",font=("bold arial",14),fg="black",bg="light grey",relief="ridge",borderwidth="2")
		self.label1b.place(x=10,y=30,width=150,height=30)

		searchbtnb=Button(Manage_frame4,text="Source",width=15,font=("times new roman",15,"bold"),command=self.Search_Flight)
		searchbtnb.place(x=160,y=70,width=140,height=30)
		entry_searchb=Entry(Manage_frame4,textvariable=self.Flgt,font=("calibri",12),bd=4,relief=GROOVE)
		entry_searchb.place(x=10,y=70,width=130,height=30)

		searchbtna=Button(Manage_frame4,text="Destination",width=15,font=("times new roman",13,"bold"),command=self.search_flight)
		searchbtna.place(x=500,y=70,width=140,height=30)
		entry_searcha=Entry(Manage_frame4,textvariable=self.FgtNme,font=("calibri",12),bd=4,relief=GROOVE)
		entry_searcha.place(x=350,y=70,width=130,height=30)

		searchbtna=Button(Manage_frame4,text="DeptDate",width=15,font=("times new roman",13,"bold"),command=self.search_date)
		searchbtna.place(x=840,y=70,width=140,height=30)
		entry_searcha=Entry(Manage_frame4,textvariable=self.dpt,font=("calibri",12),bd=4,relief=GROOVE)
		entry_searcha.place(x=690,y=70,width=130,height=30)


		showbtna=Button(Manage_frame4,text="Showall",width=15,font=("times new roman",13,"bold"),bg="light yellow",command=self.fetch_data)
		showbtna.place(x=1000,y=70,width=120,height=30)




		

		info_frameb=Frame(Manage_frame4,relief=RIDGE,bd="2",bg="light blue")
		info_frameb.place(x=30,y=140,width=1400,height=520)


		scroll1=Scrollbar(info_frameb,orient=HORIZONTAL)
		scroll1.pack(side=BOTTOM,fill=X)
		scroll2=Scrollbar(info_frameb,orient=VERTICAL)
		scroll2.pack(side=RIGHT,fill=Y)
		self.Flight_table=ttk.Treeview(info_frameb,columns=("Flight","FlightName","Source","Destination","Departure","Arrival","Charges","DeptTime"),xscrollcommand=scroll1.set,yscrollcommand=scroll2.set)
		scroll1.config(command=self.Flight_table.xview)
		scroll2.config(command=self.Flight_table.yview)

		
		self.Flight_table.heading("Flight",text="Flight ID")
		self.Flight_table.heading("FlightName",text="FlightName")
		self.Flight_table.heading("Source",text="Source")
		self.Flight_table.heading("Destination",text="Destination")
		self.Flight_table.heading("Departure",text="Departure")
		self.Flight_table.heading("Arrival",text="ArriveTime")
		self.Flight_table.heading("Charges",text="Flight Charge")
		self.Flight_table.heading("DeptTime",text="DeptDate")

		self.Flight_table['show']='headings'
		self.Flight_table.column("Flight",width=70)
		self.Flight_table.column("FlightName",width=70)
		self.Flight_table.column("Source",width=70)
		self.Flight_table.column("Destination",width=70)
		self.Flight_table.column("Departure",width=70)
		self.Flight_table.column("Arrival",width=70)
		self.Flight_table.column("Charges",width=70)
		self.Flight_table.column("DeptTime",width=70)

		self.Flight_table.pack(fill=BOTH,expand=True)
		self.fetch_data()


	def fetch_data(self):
		connection=sqlite3.connect("Airline.db")
		cursor=connection.cursor()

		line="select * from ft"
		cursor.execute(line)

		rows=cursor.fetchall()
		if len(rows)!=0:
			self.Flight_table.delete(*self.Flight_table.get_children())
			for row in rows:
				self.Flight_table.insert('',END,values=row)

			connection.commit()
		connection.close()



	def search_flight(self):
		connection=sqlite3.connect("Airline.db")
		cursor=connection.cursor()

		line="select * from ft where Destination='{}'".format(self.FgtNme.get())
		cursor.execute(line)
		rows=cursor.fetchall()
		if len(rows)!=0:
			self.Flight_table.delete(*self.Flight_table.get_children())
			for row in rows:
				self.Flight_table.insert('',END,values=row)

			connection.commit()
		connection.close()


	def Search_Flight(self):
		connection=sqlite3.connect("Airline.db")
		cursor=connection.cursor()

		line="select * from ft where Source='{}'".format(self.Flgt.get())
		cursor.execute(line)
		rows=cursor.fetchall()
		if len(rows)!=0:
			self.Flight_table.delete(*self.Flight_table.get_children())
			for row in rows:
				self.Flight_table.insert('',END,values=row)

			connection.commit()
		connection.close()

	def search_date(self):
		connection=sqlite3.connect("Airline.db")
		cursor=connection.cursor()

		line="select * from ft where DeptTime='{}'".format(self.dpt.get())
		cursor.execute(line)
		rows=cursor.fetchall()
		if len(rows)!=0:
			self.Flight_table.delete(*self.Flight_table.get_children())
			for row in rows:
				self.Flight_table.insert('',END,values=row)

			connection.commit()
		connection.close()



root.mainloop()